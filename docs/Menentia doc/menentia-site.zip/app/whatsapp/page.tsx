import type { Metadata } from 'next';
import { Icon } from '@/components/Icon';
import { ChatbotMock, RelancesMock, WhatsAppMock, WithPhone } from '@/components/mockups';
import { CtaBand } from '@/components/sections';
import { Button, Container, SectionTitle, StatusBadge } from '@/components/ui';
import { links, type Status } from '@/lib/site';

export const metadata: Metadata = {
  title: 'WhatsApp pour les PME : le guide 2026',
  description: 'WhatsApp Business ou API officielle de Meta : ce que vos clients vous écrivent, ce qui est permis, ce que ça coûte, et comment Menentia vous aide à répondre et relancer sans y passer vos journées.',
  alternates: { canonical: '/whatsapp' },
};

const questions = [
  { q: '« Vous êtes ouverts dimanche ? »', who: 'Tous les métiers', text: 'Horaires, jours fériés, pause de midi. La question la plus fréquente, et celle qui arrive le soir, quand vous êtes fermé.' },
  { q: '« Il vous reste une place samedi ? »', who: 'Salons, spas, coachs', text: 'Une demande de rendez-vous. Sans réponse dans l’heure, la cliente écrit au salon d’à côté.' },
  { q: '« C’est combien pour des tresses ? »', who: 'Beauté et soins', text: 'Les prix. Une liste claire évite dix allers-retours et fait venir la cliente avec la bonne attente.' },
  { q: '« Je peux décaler à 15 h ? »', who: 'Santé, garages, cabinets', text: 'Un rendez-vous à déplacer. Si personne ne met l’agenda à jour, le créneau reste bloqué pour rien.' },
  { q: '« Vous êtes où exactement ? »', who: 'Tous les métiers', text: 'Le quartier, le repère (« après la pharmacie »), la localisation. Simple, mais répété dix fois par jour.' },
  { q: '« Je peux payer par Airtel Money ? »', who: 'Tous les métiers', text: 'Les moyens de paiement. Mobile Money, espèces ou carte : à dire avant la visite.' },
];

const columns = ['Application WhatsApp Business', 'Menentia, sans l’API', 'Menentia, avec l’API'];
const rows: { label: string; cells: [string, string, string] }[] = [
  { label: 'Qui répond', cells: ['Vous, à la main', 'Vous, avec le message déjà prêt', 'Vous, puis bientôt l’assistant IA'] },
  { label: 'Rappels de rendez-vous', cells: ['À taper un par un', 'Listés chaque jour, envoyés en un clic', 'Envoyés en nombre, statuts remis et lu'] },
  { label: 'Prise de rendez-vous', cells: ['À noter vous-même', 'Lien de réservation dans votre statut', 'Lien de réservation, et bientôt par l’assistant'] },
  { label: 'Clients à relancer', cells: ['Personne ne vous prévient', 'Alerte de départ et liste du jour', 'Campagnes ciblées par étape et groupe'] },
  { label: 'Suivi du client', cells: ['Rien de tracé', 'Chaque relance notée sur sa fiche', 'Historique des messages sur sa fiche'] },
  { label: 'Coût', cells: ['Gratuit', 'Compris dans votre offre Menentia', 'Offre Menentia + messages facturés par Meta'] },
];

const rules = [
  { t: 'La fenêtre de 24 heures', d: 'Quand un client vous écrit, vous pouvez lui répondre librement pendant 24 heures.' },
  { t: 'Le modèle validé', d: 'Pour écrire le premier, ou au-delà de 24 heures, l’API exige un modèle de message validé à l’avance par Meta.' },
  { t: 'Le consentement', d: 'Une promotion suppose l’accord du client, daté et noté. Un rappel de rendez-vous qu’il attend n’est pas une promotion.' },
  { t: 'Le mot « Stop »', d: 'Le client doit pouvoir arrêter les messages à tout moment, d’un simple mot. Il ne reçoit plus rien ensuite.' },
  { t: 'Les données sensibles', d: 'Une ordonnance ou un dossier médical ne doit pas traîner dans un téléphone, ni être gardé plus que nécessaire.' },
  { t: 'L’assistant se présente', d: 'Un assistant automatique dit qu’il en est un, et passe la main à une personne quand on le lui demande.' },
];

const menentia: { title: string; text: string; status: Status }[] = [
  { title: 'Listes de relance du jour', text: 'Rendez-vous à rappeler, absents à reprogrammer, clients à risque, anniversaires : chacun avec son message prêt, modifiable.', status: 'dispo' },
  { title: 'Envoi en un clic depuis votre téléphone', text: 'Le message s’ouvre dans WhatsApp, déjà rempli. Aucun compte Meta nécessaire.', status: 'dispo' },
  { title: 'Lien de réservation', text: 'À mettre dans votre statut et votre profil. Le client réserve seul et reçoit son récapitulatif sur WhatsApp.', status: 'dispo' },
  { title: 'Consentement par QR code', text: 'Une affiche en caisse : le client scanne, écrit « OUI », son accord est daté et sourcé.', status: 'dispo' },
  { title: 'Campagnes par l’API officielle', text: 'Avec votre compte WhatsApp Business API : modèles Meta, envoi par lots, statuts remis et lu, coût estimé avant l’envoi.', status: 'dispo' },
  { title: 'Réponse « Stop » respectée', text: 'Le client qui répond « Stop » perd son accord automatiquement et ne reçoit plus de campagne.', status: 'dispo' },
  { title: 'Rappels automatiques', text: 'La veille et 2 h avant, avec réponse « 1 = je confirme, 2 = j’annule ».', status: 'bientot' },
  { title: 'Assistant IA sur WhatsApp', text: 'Il répond jour et nuit à partir de votre fiche (horaires, adresse, prix), propose vos vrais créneaux et vous passe la main quand il ne sait pas.', status: 'bientot' },
];

const faq = [
  { q: 'Puis-je utiliser Menentia sans l’API WhatsApp ?', a: 'Oui, c’est même le mode par défaut à l’inscription. Menentia prépare les messages et vous les envoyez en un clic depuis le WhatsApp de votre établissement.' },
  { q: 'Quelle différence entre l’application et l’API ?', a: 'L’application WhatsApp Business est gratuite et s’utilise à la main sur un téléphone. L’API officielle de Meta permet à un logiciel comme Menentia d’envoyer des messages en nombre, de suivre leur statut et, bientôt, de répondre seul.' },
  { q: 'Combien coûte l’API WhatsApp ?', a: 'Meta facture les messages envoyés hors fenêtre de 24 heures, selon leur catégorie et le pays du client. Menentia affiche le coût estimé avant chaque campagne.' },
  { q: 'Le client doit-il donner son accord ?', a: 'Pour une promotion, oui. Menentia enregistre la date et la source de chaque accord (QR code, réservation en ligne, import) et n’envoie aucune campagne à un client sans accord.' },
  { q: 'Faut-il un numéro dédié ?', a: 'Sans l’API, vous gardez votre numéro actuel. Pour l’API, on conseille un numéro réservé à l’établissement ; selon votre situation, Meta permet parfois de garder aussi l’application sur le même numéro. Nous vérifions ce point avec vous à l’installation.' },
  { q: 'L’assistant IA peut-il se tromper ?', a: 'Il ne répond qu’à partir des informations de votre fiche et de votre agenda. Quand il ne sait pas, il le dit et vous transmet la question. Il arrive avec une prochaine version.' },
];

export default function WhatsAppGuide() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-line bg-[#F7FAFD]">
        <Container className="grid items-center gap-12 py-14 lg:grid-cols-[1.15fr_1fr] lg:py-20">
          <div className="flex min-w-0 flex-col gap-6">
            <p className="text-[13px] font-bold uppercase tracking-[0.16em] text-green-text">WhatsApp pour les PME</p>
            <h1 className="text-balance font-display text-[2.4rem] font-bold leading-[1.05] tracking-[-0.025em] text-navy sm:text-[3.1rem]">WhatsApp Business pour les entreprises sur rendez-vous&nbsp;: le guide 2026</h1>
            <p className="max-w-xl text-[1.08rem] leading-relaxed text-muted">Vos clients ont WhatsApp dans la poche. Ils vous écrivent le soir, le dimanche, pendant que vous êtes avec quelqu’un. Voici ce qui est permis, ce que ça coûte, et comment répondre et relancer sans y passer vos journées.</p>
            <div className="rounded-2xl border border-line bg-white p-5">
              <p className="text-[12px] font-bold uppercase tracking-[0.14em] text-blue-text">Réponse directe</p>
              <p className="mt-2 text-[15.5px] leading-relaxed text-ink">Il y a deux façons d’utiliser WhatsApp avec vos clients : l’application WhatsApp Business, gratuite, où quelqu’un écrit à la main ; ou l’API officielle de Meta, branchée sur un logiciel, qui envoie rappels et campagnes en nombre. Menentia fonctionne avec les deux : sans l’API, il prépare chaque message et vous l’envoyez en un clic ; avec votre compte API, il envoie et suit les campagnes pour vous.</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button href="/contact" variant="dark" size="lg">Voir une démonstration</Button>
              <a href={links.signup} className="inline-flex items-center gap-1.5 whitespace-nowrap px-2 font-semibold text-blue-text">ou commencer l’essai gratuit <Icon name="arrow" className="h-4 w-4" /></a>
            </div>
          </div>
          <div className="min-w-0"><WithPhone main={<RelancesMock />} phone={<WhatsAppMock />} /></div>
        </Container>
      </section>

      <section className="py-20">
        <Container className="flex flex-col gap-10">
          <SectionTitle eyebrow="Ce que vos clients vous écrivent" title="Les mêmes questions, tous les jours." lead="Dans une entreprise sur rendez-vous, les messages se ressemblent d’un client à l’autre. C’est ce qui rend WhatsApp si utile, et si prenant quand on répond à la main." />
          <ul className="grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {questions.map((q) => (
              <li key={q.q} className="flex flex-col gap-2 bg-white p-6">
                <p className="font-display text-[18px] font-bold leading-snug text-navy">{q.q}</p>
                <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-green-text">{q.who}</p>
                <p className="text-[14.5px] leading-relaxed text-muted">{q.text}</p>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      <section className="border-y border-line bg-soft py-20">
        <Container className="flex flex-col gap-10">
          <SectionTitle eyebrow="Comparer" title={'L’application ou Menentia\u00a0: la vraie différence.'} />
          <div className="overflow-x-auto rounded-2xl border border-line bg-white">
            <table className="w-full min-w-[720px] border-collapse text-left text-[14.5px]">
              <thead>
                <tr className="border-b border-line">
                  <th scope="col" className="p-5" />
                  {columns.map((c, i) => (
                    <th key={c} scope="col" className={`p-5 font-display text-[15px] font-bold ${i === 2 ? 'text-blue-text' : 'text-navy'}`}>{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.label} className="border-b border-line last:border-b-0">
                    <th scope="row" className="p-5 font-semibold text-navy">{r.label}</th>
                    {r.cells.map((c, i) => (
                      <td key={i} className={`p-5 ${i === 0 ? 'text-muted' : 'text-ink'}`}>{c}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Container>
      </section>

      <section className="py-20">
        <Container className="grid gap-12 lg:grid-cols-[1fr_1.3fr]">
          <SectionTitle eyebrow="Les règles à connaître" title="Ce que WhatsApp permet, et ce qu’il interdit." lead="Ces règles viennent de Meta et des lois sur les données personnelles. Menentia les applique pour vous." />
          <ol className="grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2">
            {rules.map((r, i) => (
              <li key={r.t} className="flex flex-col gap-2 bg-white p-6">
                <span className="text-[12px] font-bold tabular-nums tracking-[0.14em] text-muted">{String(i + 1).padStart(2, '0')}</span>
                <p className="font-display text-[17px] font-bold text-navy">{r.t}</p>
                <p className="text-[14.5px] leading-relaxed text-muted">{r.d}</p>
              </li>
            ))}
          </ol>
        </Container>
      </section>

      <section className="bg-navy py-20 text-white">
        <Container className="grid items-center gap-12 lg:grid-cols-[1.3fr_1fr]">
          <div className="flex flex-col gap-8">
            <SectionTitle light eyebrow="Ce que fait Menentia" title="Répondre, rappeler, relancer, au nom de votre établissement." />
            <ul className="grid gap-4 sm:grid-cols-2">
              {menentia.map((m) => (
                <li key={m.title} className="flex flex-col gap-2 rounded-2xl border border-white/10 bg-white/5 p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-display text-[16.5px] font-bold">{m.title}</p>
                    <StatusBadge status={m.status} />
                  </div>
                  <p className="text-[14px] leading-relaxed text-[#C9D6E3]">{m.text}</p>
                </li>
              ))}
            </ul>
          </div>
          <div className="flex justify-center"><ChatbotMock /></div>
        </Container>
      </section>

      <section className="py-20">
        <Container className="flex flex-col gap-10">
          <SectionTitle center eyebrow="Questions fréquentes" title="WhatsApp et Menentia, en clair." />
          <div className="mx-auto flex w-full max-w-3xl flex-col divide-y divide-line rounded-2xl border border-line bg-white">
            {faq.map((o) => (
              <details key={o.q} className="group px-6 py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-[17px] font-bold text-navy [&::-webkit-details-marker]:hidden">
                  {o.q}
                  <Icon name="chevron" className="h-5 w-5 shrink-0 text-muted transition group-open:rotate-180" />
                </summary>
                <p className="pt-3 text-[15.5px] leading-relaxed text-muted">{o.a}</p>
              </details>
            ))}
          </div>
        </Container>
      </section>

      <CtaBand />
    </>
  );
}
